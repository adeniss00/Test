package com.example.backend.repository;

/**
 * @author : Adeniss
 **/

import com.example.backend.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
//generated with love by testme